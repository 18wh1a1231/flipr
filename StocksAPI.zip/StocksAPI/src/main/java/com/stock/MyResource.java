package com.stock;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.dao.BseDao;
import com.dao.NseDao;
import com.dto.BSE;
import com.dto.NSE;


@Path("myresource")
public class MyResource {

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
    
    @Path("getBseDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<BSE> getDetailsBse(){
		System.out.println("Recieved in getAllEmployees : " ); 
		BseDao bseDao = new BseDao();
		List<BSE> bseList = bseDao.getBseDetails();	
		return  bseList;	
	}
    
    @Path("getNseDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<NSE> getDetailsNse(){
		System.out.println("Recieved in getAllEmployees : " ); 
		NseDao nseDao = new NseDao();
		List<NSE> nseList = nseDao.getNseDetails();	
		return nseList;	
	}
}
