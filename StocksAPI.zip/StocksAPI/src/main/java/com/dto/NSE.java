package com.dto;

import java.util.Date;

public class NSE {
	
	private Date Date;
	private double Open;
	private double High;
	private double Low;
	private double Close;
	private double AdjClose;
	private int Volume;
	
	
	public NSE() {
		super();
		// TODO Auto-generated constructor stub
	}


	public NSE(java.util.Date date, double open, double high, double low, double close, double adjClose, int volume) {
		super();
		Date = date;
		Open = open;
		High = high;
		Low = low;
		Close = close;
		AdjClose = adjClose;
		Volume = volume;
	}


	public Date getDate() {
		return Date;
	}


	public void setDate(Date date) {
		Date = date;
	}


	public double getOpen() {
		return Open;
	}


	public void setOpen(double open) {
		Open = open;
	}


	public double getHigh() {
		return High;
	}


	public void setHigh(double high) {
		High = high;
	}


	public double getLow() {
		return Low;
	}


	public void setLow(double low) {
		Low = low;
	}


	public double getClose() {
		return Close;
	}


	public void setClose(double close) {
		Close = close;
	}


	public double getAdjClose() {
		return AdjClose;
	}


	public void setAdjClose(double adjClose) {
		AdjClose = adjClose;
	}


	public int getVolume() {
		return Volume;
	}


	public void setVolume(int volume) {
		Volume = volume;
	}

}
