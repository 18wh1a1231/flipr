package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import com.dto.NSE;

public class NseDao {
	
	public List<NSE> getNseDetails() {
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Query q1 = session.createQuery("from Employee e");
		List<NSE> nseList = q1.list();
		session.close();
		return nseList;
	}

}
