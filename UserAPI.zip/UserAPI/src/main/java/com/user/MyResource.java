package com.user;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.catalina.User;

import com.dao.UserDao;


@Path("myresource")
public class MyResource {
	
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
    
    
    @Path("registerUser")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void resisterUser(User user) {
		System.out.println("Data Recieved in Register : " + user); 
		UserDao userDao = new UserDao();
		userDao.register(user); 
	}
}
