package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.jvnet.hk2.annotations.Service;


import com.dto.RELIANCE;

@Service
public class RelianceDao {
	
	
	public List<RELIANCE> getRelianceDetails() {
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		SessionFactory factory = config.buildSessionFactory();
		Session session = factory.openSession();
		Query q1 = session.createQuery("from Employee e");
		List<RELIANCE> relianceList = q1.list();
		session.close();
		return relianceList;
	}

}
