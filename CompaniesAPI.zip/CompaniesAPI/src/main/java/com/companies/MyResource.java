package com.companies;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.dao.AshokLeyDao;
import com.dao.CiplaDao;
import com.dao.EicherMotDao;
import com.dao.RelianceDao;
import com.dao.TataSteelDao;
import com.dto.ASHOKLEY;
import com.dto.CIPLA;
import com.dto.EICHERMOT;
import com.dto.RELIANCE;
import com.dto.TATASTEEL;


@Path("myresource")
public class MyResource {

   
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getIt() {
        return "Got it!";
    }
    
    
    @Path("getAshokLeyDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<ASHOKLEY> getDetailsAshokLey(){
		System.out.println("Recieved in getDetails : " ); 
		AshokLeyDao ashokLeyDao = new AshokLeyDao();
		List<ASHOKLEY> ashokLeyList = ashokLeyDao.getAshokLeyDetails();	
		return ashokLeyList;	
	}
    
    @Path("getCiplaDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<CIPLA> GetDetailsCipla(){
		System.out.println("Recieved in getDetails : " ); 
		CiplaDao ciplaDao = new CiplaDao();
		List<CIPLA> ciplaList = ciplaDao.getCiplaDetails();	
		return ciplaList;	
	}
    
    @Path("getEicherMotDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<EICHERMOT> getDetailsEicher(){
		System.out.println("Recieved in getDetails : " ); 
		EicherMotDao eicherMotDao = new EicherMotDao();
		List<EICHERMOT> eicherMotList = eicherMotDao.getEicherMotDetails();	
		return eicherMotList;	
	}
    
    @Path("getRelianceDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<RELIANCE> getDetailsReliance(){
		System.out.println("Recieved in getDetails : " ); 
		RelianceDao relianceDao = new RelianceDao();
		List<RELIANCE> relianceList = relianceDao .getRelianceDetails();
		return relianceList;	
	}
    
    @Path("getTataSteelDetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<TATASTEEL> getDetailsTataSteel(){
		System.out.println("Recieved in getDetails : " ); 
		TataSteelDao tataSteelDao = new TataSteelDao();
		List<TATASTEEL> tataSteelList = tataSteelDao.getTataSteelDetails();	
		return tataSteelList;	
	}
}
